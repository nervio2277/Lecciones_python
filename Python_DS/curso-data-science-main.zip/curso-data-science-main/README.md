🔥 Mi formulario de Python para data science: https://artificialcorner.com/p/formularios-gratis-de-python

Nota: El dataset de la ultima seccion no lo pude subit a GitHub porque pesaba mucho. Pueden descargarlo aqui: https://www.kaggle.com/lakshmi25npathi/imdb-dataset-of-50k-movie-reviews
